﻿namespace AS2020_DronTaxi
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.lbNameApp = new System.Windows.Forms.Label();
            this.plMyProfile = new System.Windows.Forms.Panel();
            this.plRole = new System.Windows.Forms.Panel();
            this.tbPPassword = new System.Windows.Forms.TextBox();
            this.lbPPassword = new System.Windows.Forms.Label();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.btSave = new System.Windows.Forms.Button();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.btCancel = new System.Windows.Forms.Button();
            this.mtbBirthDay = new System.Windows.Forms.MaskedTextBox();
            this.mtbTelephone = new System.Windows.Forms.MaskedTextBox();
            this.tbSex = new System.Windows.Forms.TextBox();
            this.btReg = new System.Windows.Forms.Button();
            this.lbSex = new System.Windows.Forms.Label();
            this.lbBirthDay = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbSecondName = new System.Windows.Forms.Label();
            this.tbSecondName = new System.Windows.Forms.TextBox();
            this.lbPassword = new System.Windows.Forms.Label();
            this.lbFirstName = new System.Windows.Forms.Label();
            this.lbTelephone = new System.Windows.Forms.Label();
            this.tbFirstName = new System.Windows.Forms.TextBox();
            this.lbEmail = new System.Windows.Forms.Label();
            this.lbLastName = new System.Windows.Forms.Label();
            this.tbLastName = new System.Windows.Forms.TextBox();
            this.pbLogoApp = new System.Windows.Forms.PictureBox();
            this.lbMyProfile = new System.Windows.Forms.Label();
            this.pbMyProfile = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.lbRole = new System.Windows.Forms.Label();
            this.pbRole = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.aS2020DataSet = new AS2020_DronTaxi.AS2020DataSet();
            this.aS2020DataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.v_user_poreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.v_user_poreTableAdapter = new AS2020_DronTaxi.AS2020DataSetTableAdapters.v_user_poreTableAdapter();
            this.tableAdapterManager = new AS2020_DronTaxi.AS2020DataSetTableAdapters.TableAdapterManager();
            this.plMyProfile.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogoApp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMyProfile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRole)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aS2020DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aS2020DataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.v_user_poreBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lbNameApp
            // 
            this.lbNameApp.AutoSize = true;
            this.lbNameApp.BackColor = System.Drawing.Color.Transparent;
            this.lbNameApp.Enabled = false;
            this.lbNameApp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbNameApp.Font = new System.Drawing.Font("Roboto Cn", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbNameApp.ForeColor = System.Drawing.SystemColors.Control;
            this.lbNameApp.Location = new System.Drawing.Point(112, 20);
            this.lbNameApp.Name = "lbNameApp";
            this.lbNameApp.Size = new System.Drawing.Size(238, 58);
            this.lbNameApp.TabIndex = 2;
            this.lbNameApp.Text = "DRON TAXI";
            this.lbNameApp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // plMyProfile
            // 
            this.plMyProfile.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.plMyProfile.BackColor = System.Drawing.Color.DarkMagenta;
            this.plMyProfile.Controls.Add(this.plRole);
            this.plMyProfile.Controls.Add(this.tbPPassword);
            this.plMyProfile.Controls.Add(this.lbPPassword);
            this.plMyProfile.Controls.Add(this.tbPassword);
            this.plMyProfile.Controls.Add(this.btSave);
            this.plMyProfile.Controls.Add(this.tbEmail);
            this.plMyProfile.Controls.Add(this.btCancel);
            this.plMyProfile.Controls.Add(this.mtbBirthDay);
            this.plMyProfile.Controls.Add(this.mtbTelephone);
            this.plMyProfile.Controls.Add(this.tbSex);
            this.plMyProfile.Controls.Add(this.btReg);
            this.plMyProfile.Controls.Add(this.lbSex);
            this.plMyProfile.Controls.Add(this.lbBirthDay);
            this.plMyProfile.Controls.Add(this.pictureBox1);
            this.plMyProfile.Controls.Add(this.lbSecondName);
            this.plMyProfile.Controls.Add(this.tbSecondName);
            this.plMyProfile.Controls.Add(this.lbPassword);
            this.plMyProfile.Controls.Add(this.lbFirstName);
            this.plMyProfile.Controls.Add(this.lbTelephone);
            this.plMyProfile.Controls.Add(this.tbFirstName);
            this.plMyProfile.Controls.Add(this.lbEmail);
            this.plMyProfile.Controls.Add(this.lbLastName);
            this.plMyProfile.Controls.Add(this.tbLastName);
            this.plMyProfile.Location = new System.Drawing.Point(189, 124);
            this.plMyProfile.Name = "plMyProfile";
            this.plMyProfile.Size = new System.Drawing.Size(896, 430);
            this.plMyProfile.TabIndex = 33;
            // 
            // plRole
            // 
            this.plRole.Location = new System.Drawing.Point(3, 0);
            this.plRole.Name = "plRole";
            this.plRole.Size = new System.Drawing.Size(887, 416);
            this.plRole.TabIndex = 83;
            this.plRole.Visible = false;
            // 
            // tbPPassword
            // 
            this.tbPPassword.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbPPassword.BackColor = System.Drawing.Color.DarkMagenta;
            this.tbPPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbPPassword.Enabled = false;
            this.tbPPassword.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbPPassword.ForeColor = System.Drawing.SystemColors.Window;
            this.tbPPassword.Location = new System.Drawing.Point(561, 267);
            this.tbPPassword.Name = "tbPPassword";
            this.tbPPassword.PasswordChar = '*';
            this.tbPPassword.Size = new System.Drawing.Size(285, 20);
            this.tbPPassword.TabIndex = 81;
            this.tbPPassword.Text = "Пароль";
            this.tbPPassword.Visible = false;
            // 
            // lbPPassword
            // 
            this.lbPPassword.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbPPassword.AutoSize = true;
            this.lbPPassword.BackColor = System.Drawing.Color.Transparent;
            this.lbPPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbPPassword.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbPPassword.ForeColor = System.Drawing.SystemColors.Control;
            this.lbPPassword.Location = new System.Drawing.Point(555, 245);
            this.lbPPassword.Name = "lbPPassword";
            this.lbPPassword.Size = new System.Drawing.Size(148, 19);
            this.lbPPassword.TabIndex = 82;
            this.lbPPassword.Text = "Повторить пароль";
            this.lbPPassword.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbPPassword.Visible = false;
            // 
            // tbPassword
            // 
            this.tbPassword.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbPassword.BackColor = System.Drawing.Color.DarkMagenta;
            this.tbPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbPassword.Enabled = false;
            this.tbPassword.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbPassword.ForeColor = System.Drawing.SystemColors.Window;
            this.tbPassword.Location = new System.Drawing.Point(561, 209);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.PasswordChar = '*';
            this.tbPassword.Size = new System.Drawing.Size(285, 20);
            this.tbPassword.TabIndex = 8;
            this.tbPassword.Text = "Пароль";
            // 
            // btSave
            // 
            this.btSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btSave.BackColor = System.Drawing.Color.SpringGreen;
            this.btSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btSave.Font = new System.Drawing.Font("Roboto Cn", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btSave.ForeColor = System.Drawing.SystemColors.Control;
            this.btSave.Location = new System.Drawing.Point(537, 371);
            this.btSave.Name = "btSave";
            this.btSave.Size = new System.Drawing.Size(147, 32);
            this.btSave.TabIndex = 77;
            this.btSave.Text = "Сохранить";
            this.btSave.UseVisualStyleBackColor = false;
            this.btSave.Visible = false;
            this.btSave.Click += new System.EventHandler(this.btSave_Click);
            // 
            // tbEmail
            // 
            this.tbEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbEmail.BackColor = System.Drawing.Color.DarkMagenta;
            this.tbEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbEmail.Enabled = false;
            this.tbEmail.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbEmail.ForeColor = System.Drawing.SystemColors.Window;
            this.tbEmail.Location = new System.Drawing.Point(561, 85);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(285, 20);
            this.tbEmail.TabIndex = 6;
            this.tbEmail.Text = "Email";
            // 
            // btCancel
            // 
            this.btCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btCancel.BackColor = System.Drawing.Color.Turquoise;
            this.btCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btCancel.Font = new System.Drawing.Font("Roboto Cn", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btCancel.ForeColor = System.Drawing.SystemColors.Control;
            this.btCancel.Location = new System.Drawing.Point(721, 371);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(158, 32);
            this.btCancel.TabIndex = 76;
            this.btCancel.Text = "Отмена";
            this.btCancel.UseVisualStyleBackColor = false;
            this.btCancel.Visible = false;
            this.btCancel.Click += new System.EventHandler(this.btCancel_Click);
            // 
            // mtbBirthDay
            // 
            this.mtbBirthDay.BackColor = System.Drawing.Color.DarkMagenta;
            this.mtbBirthDay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mtbBirthDay.Enabled = false;
            this.mtbBirthDay.Font = new System.Drawing.Font("Roboto Cn", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mtbBirthDay.ForeColor = System.Drawing.SystemColors.Window;
            this.mtbBirthDay.Location = new System.Drawing.Point(200, 267);
            this.mtbBirthDay.Mask = "00/00/0000";
            this.mtbBirthDay.Name = "mtbBirthDay";
            this.mtbBirthDay.Size = new System.Drawing.Size(123, 20);
            this.mtbBirthDay.TabIndex = 4;
            this.mtbBirthDay.Text = "00000000";
            this.mtbBirthDay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mtbBirthDay.ValidatingType = typeof(System.DateTime);
            // 
            // mtbTelephone
            // 
            this.mtbTelephone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mtbTelephone.BackColor = System.Drawing.Color.DarkMagenta;
            this.mtbTelephone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mtbTelephone.Enabled = false;
            this.mtbTelephone.Font = new System.Drawing.Font("Roboto Cn", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mtbTelephone.ForeColor = System.Drawing.SystemColors.Window;
            this.mtbTelephone.Location = new System.Drawing.Point(561, 147);
            this.mtbTelephone.Mask = "(999) 000-0000";
            this.mtbTelephone.Name = "mtbTelephone";
            this.mtbTelephone.Size = new System.Drawing.Size(285, 20);
            this.mtbTelephone.TabIndex = 7;
            this.mtbTelephone.Text = "1234567890";
            // 
            // tbSex
            // 
            this.tbSex.BackColor = System.Drawing.Color.DarkMagenta;
            this.tbSex.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSex.Enabled = false;
            this.tbSex.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbSex.ForeColor = System.Drawing.SystemColors.Window;
            this.tbSex.Location = new System.Drawing.Point(344, 267);
            this.tbSex.Name = "tbSex";
            this.tbSex.Size = new System.Drawing.Size(141, 20);
            this.tbSex.TabIndex = 5;
            this.tbSex.Text = "Пол";
            this.tbSex.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btReg
            // 
            this.btReg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btReg.BackColor = System.Drawing.Color.Turquoise;
            this.btReg.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btReg.Font = new System.Drawing.Font("Roboto Cn", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btReg.ForeColor = System.Drawing.SystemColors.Control;
            this.btReg.Location = new System.Drawing.Point(668, 34);
            this.btReg.Name = "btReg";
            this.btReg.Size = new System.Drawing.Size(147, 32);
            this.btReg.TabIndex = 75;
            this.btReg.Text = "Редактировать";
            this.btReg.UseVisualStyleBackColor = false;
            this.btReg.Click += new System.EventHandler(this.btReg_Click);
            // 
            // lbSex
            // 
            this.lbSex.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbSex.AutoSize = true;
            this.lbSex.BackColor = System.Drawing.Color.Transparent;
            this.lbSex.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbSex.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbSex.ForeColor = System.Drawing.SystemColors.Control;
            this.lbSex.Location = new System.Drawing.Point(340, 245);
            this.lbSex.Name = "lbSex";
            this.lbSex.Size = new System.Drawing.Size(38, 19);
            this.lbSex.TabIndex = 71;
            this.lbSex.Text = "Пол";
            this.lbSex.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbBirthDay
            // 
            this.lbBirthDay.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbBirthDay.AutoSize = true;
            this.lbBirthDay.BackColor = System.Drawing.Color.Transparent;
            this.lbBirthDay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbBirthDay.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbBirthDay.ForeColor = System.Drawing.SystemColors.Control;
            this.lbBirthDay.Location = new System.Drawing.Point(196, 245);
            this.lbBirthDay.Name = "lbBirthDay";
            this.lbBirthDay.Size = new System.Drawing.Size(127, 19);
            this.lbBirthDay.TabIndex = 69;
            this.lbBirthDay.Text = "День рождения";
            this.lbBirthDay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::AS2020_DronTaxi.Properties.Resources.clear_prof_circle;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.InitialImage = global::AS2020_DronTaxi.Properties.Resources.clear_prof;
            this.pictureBox1.Location = new System.Drawing.Point(32, 64);
            this.pictureBox1.MaximumSize = new System.Drawing.Size(103, 92);
            this.pictureBox1.MinimumSize = new System.Drawing.Size(103, 92);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 92);
            this.pictureBox1.TabIndex = 62;
            this.pictureBox1.TabStop = false;
            // 
            // lbSecondName
            // 
            this.lbSecondName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbSecondName.AutoSize = true;
            this.lbSecondName.BackColor = System.Drawing.Color.Transparent;
            this.lbSecondName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbSecondName.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbSecondName.ForeColor = System.Drawing.SystemColors.Control;
            this.lbSecondName.Location = new System.Drawing.Point(196, 63);
            this.lbSecondName.Name = "lbSecondName";
            this.lbSecondName.Size = new System.Drawing.Size(78, 19);
            this.lbSecondName.TabIndex = 63;
            this.lbSecondName.Text = "Фамилия";
            this.lbSecondName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbSecondName
            // 
            this.tbSecondName.BackColor = System.Drawing.Color.DarkMagenta;
            this.tbSecondName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSecondName.Enabled = false;
            this.tbSecondName.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbSecondName.ForeColor = System.Drawing.SystemColors.Window;
            this.tbSecondName.Location = new System.Drawing.Point(200, 85);
            this.tbSecondName.Name = "tbSecondName";
            this.tbSecondName.Size = new System.Drawing.Size(285, 20);
            this.tbSecondName.TabIndex = 1;
            this.tbSecondName.Text = "Фамилия";
            // 
            // lbPassword
            // 
            this.lbPassword.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbPassword.AutoSize = true;
            this.lbPassword.BackColor = System.Drawing.Color.Transparent;
            this.lbPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbPassword.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbPassword.ForeColor = System.Drawing.SystemColors.Control;
            this.lbPassword.Location = new System.Drawing.Point(555, 187);
            this.lbPassword.Name = "lbPassword";
            this.lbPassword.Size = new System.Drawing.Size(65, 19);
            this.lbPassword.TabIndex = 68;
            this.lbPassword.Text = "Пароль";
            this.lbPassword.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbFirstName
            // 
            this.lbFirstName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbFirstName.AutoSize = true;
            this.lbFirstName.BackColor = System.Drawing.Color.Transparent;
            this.lbFirstName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbFirstName.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbFirstName.ForeColor = System.Drawing.SystemColors.Control;
            this.lbFirstName.Location = new System.Drawing.Point(196, 125);
            this.lbFirstName.Name = "lbFirstName";
            this.lbFirstName.Size = new System.Drawing.Size(41, 19);
            this.lbFirstName.TabIndex = 64;
            this.lbFirstName.Text = "Имя";
            this.lbFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTelephone
            // 
            this.lbTelephone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbTelephone.AutoSize = true;
            this.lbTelephone.BackColor = System.Drawing.Color.Transparent;
            this.lbTelephone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbTelephone.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbTelephone.ForeColor = System.Drawing.SystemColors.Control;
            this.lbTelephone.Location = new System.Drawing.Point(555, 124);
            this.lbTelephone.Name = "lbTelephone";
            this.lbTelephone.Size = new System.Drawing.Size(75, 19);
            this.lbTelephone.TabIndex = 67;
            this.lbTelephone.Text = "Телефон";
            this.lbTelephone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbFirstName
            // 
            this.tbFirstName.BackColor = System.Drawing.Color.DarkMagenta;
            this.tbFirstName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbFirstName.Enabled = false;
            this.tbFirstName.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbFirstName.ForeColor = System.Drawing.SystemColors.Window;
            this.tbFirstName.Location = new System.Drawing.Point(200, 147);
            this.tbFirstName.Name = "tbFirstName";
            this.tbFirstName.Size = new System.Drawing.Size(285, 20);
            this.tbFirstName.TabIndex = 2;
            this.tbFirstName.Text = "Имя";
            // 
            // lbEmail
            // 
            this.lbEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbEmail.AutoSize = true;
            this.lbEmail.BackColor = System.Drawing.Color.Transparent;
            this.lbEmail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbEmail.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbEmail.ForeColor = System.Drawing.SystemColors.Control;
            this.lbEmail.Location = new System.Drawing.Point(555, 63);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(49, 19);
            this.lbEmail.TabIndex = 66;
            this.lbEmail.Text = "Email";
            this.lbEmail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLastName
            // 
            this.lbLastName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbLastName.AutoSize = true;
            this.lbLastName.BackColor = System.Drawing.Color.Transparent;
            this.lbLastName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbLastName.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbLastName.ForeColor = System.Drawing.SystemColors.Control;
            this.lbLastName.Location = new System.Drawing.Point(196, 187);
            this.lbLastName.Name = "lbLastName";
            this.lbLastName.Size = new System.Drawing.Size(79, 19);
            this.lbLastName.TabIndex = 65;
            this.lbLastName.Text = "Отчестов";
            this.lbLastName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbLastName
            // 
            this.tbLastName.BackColor = System.Drawing.Color.DarkMagenta;
            this.tbLastName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbLastName.Enabled = false;
            this.tbLastName.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbLastName.ForeColor = System.Drawing.SystemColors.Window;
            this.tbLastName.Location = new System.Drawing.Point(200, 209);
            this.tbLastName.Name = "tbLastName";
            this.tbLastName.Size = new System.Drawing.Size(285, 20);
            this.tbLastName.TabIndex = 3;
            this.tbLastName.Text = "Отчество";
            // 
            // pbLogoApp
            // 
            this.pbLogoApp.BackColor = System.Drawing.Color.Transparent;
            this.pbLogoApp.Image = ((System.Drawing.Image)(resources.GetObject("pbLogoApp.Image")));
            this.pbLogoApp.InitialImage = null;
            this.pbLogoApp.Location = new System.Drawing.Point(10, 10);
            this.pbLogoApp.Name = "pbLogoApp";
            this.pbLogoApp.Size = new System.Drawing.Size(96, 78);
            this.pbLogoApp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogoApp.TabIndex = 3;
            this.pbLogoApp.TabStop = false;
            // 
            // lbMyProfile
            // 
            this.lbMyProfile.AutoSize = true;
            this.lbMyProfile.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbMyProfile.Enabled = false;
            this.lbMyProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbMyProfile.Font = new System.Drawing.Font("Roboto", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbMyProfile.ForeColor = System.Drawing.SystemColors.Control;
            this.lbMyProfile.Location = new System.Drawing.Point(226, 92);
            this.lbMyProfile.Name = "lbMyProfile";
            this.lbMyProfile.Size = new System.Drawing.Size(171, 29);
            this.lbMyProfile.TabIndex = 42;
            this.lbMyProfile.Text = "Мой профиль";
            this.lbMyProfile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbMyProfile
            // 
            this.pbMyProfile.BackColor = System.Drawing.Color.DarkMagenta;
            this.pbMyProfile.Location = new System.Drawing.Point(189, 86);
            this.pbMyProfile.Name = "pbMyProfile";
            this.pbMyProfile.Size = new System.Drawing.Size(244, 40);
            this.pbMyProfile.TabIndex = 41;
            this.pbMyProfile.TabStop = false;
            this.pbMyProfile.Click += new System.EventHandler(this.pbMyProfile_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(44, 141);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(124, 46);
            this.button1.TabIndex = 34;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(44, 234);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(124, 46);
            this.button2.TabIndex = 35;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lbRole
            // 
            this.lbRole.AutoSize = true;
            this.lbRole.BackColor = System.Drawing.Color.DeepPink;
            this.lbRole.Enabled = false;
            this.lbRole.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbRole.Font = new System.Drawing.Font("Roboto", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbRole.ForeColor = System.Drawing.SystemColors.Control;
            this.lbRole.Location = new System.Drawing.Point(518, 92);
            this.lbRole.Name = "lbRole";
            this.lbRole.Size = new System.Drawing.Size(69, 29);
            this.lbRole.TabIndex = 74;
            this.lbRole.Text = "Роли";
            this.lbRole.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbRole
            // 
            this.pbRole.BackColor = System.Drawing.Color.DeepPink;
            this.pbRole.Location = new System.Drawing.Point(430, 86);
            this.pbRole.Name = "pbRole";
            this.pbRole.Size = new System.Drawing.Size(244, 40);
            this.pbRole.TabIndex = 80;
            this.pbRole.TabStop = false;
            this.pbRole.Click += new System.EventHandler(this.pbRole_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.DarkMagenta;
            this.pictureBox3.Location = new System.Drawing.Point(189, 86);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(887, 459);
            this.pictureBox3.TabIndex = 81;
            this.pictureBox3.TabStop = false;
            // 
            // aS2020DataSet
            // 
            this.aS2020DataSet.DataSetName = "AS2020DataSet";
            this.aS2020DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aS2020DataSetBindingSource
            // 
            this.aS2020DataSetBindingSource.DataSource = this.aS2020DataSet;
            this.aS2020DataSetBindingSource.Position = 0;
            // 
            // v_user_poreBindingSource
            // 
            this.v_user_poreBindingSource.DataMember = "v_user_pore";
            this.v_user_poreBindingSource.DataSource = this.aS2020DataSet;
            // 
            // v_user_poreTableAdapter
            // 
            this.v_user_poreTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.funs_rolesTableAdapter = null;
            this.tableAdapterManager.funs_sysTableAdapter = null;
            this.tableAdapterManager.order_taxiTableAdapter = null;
            this.tableAdapterManager.roles_usersTableAdapter = null;
            this.tableAdapterManager.rolesTableAdapter = null;
            this.tableAdapterManager.sessionsTableAdapter = null;
            this.tableAdapterManager.trasportsTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = AS2020_DronTaxi.AS2020DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.usersTableAdapter = null;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.MediumVioletRed;
            this.ClientSize = new System.Drawing.Size(1070, 536);
            this.Controls.Add(this.plMyProfile);
            this.Controls.Add(this.lbMyProfile);
            this.Controls.Add(this.pbMyProfile);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pbLogoApp);
            this.Controls.Add(this.lbRole);
            this.Controls.Add(this.lbNameApp);
            this.Controls.Add(this.pbRole);
            this.Controls.Add(this.pictureBox3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1086, 575);
            this.MinimumSize = new System.Drawing.Size(1086, 575);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Drom Taxi";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Main_FormClosed);
            this.Load += new System.EventHandler(this.Main_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Main_KeyDown);
            this.plMyProfile.ResumeLayout(false);
            this.plMyProfile.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogoApp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMyProfile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRole)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aS2020DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aS2020DataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.v_user_poreBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pbLogoApp;
        private System.Windows.Forms.Label lbNameApp;
        private System.Windows.Forms.Panel plMyProfile;
        private System.Windows.Forms.Label lbMyProfile;
        private System.Windows.Forms.PictureBox pbMyProfile;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btReg;
        private System.Windows.Forms.Label lbRole;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbSecondName;
        private System.Windows.Forms.TextBox tbSecondName;
        private System.Windows.Forms.Label lbFirstName;
        private System.Windows.Forms.TextBox tbFirstName;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.Label lbLastName;
        private System.Windows.Forms.TextBox tbLastName;
        private System.Windows.Forms.Button btSave;
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.MaskedTextBox mtbTelephone;
        private System.Windows.Forms.MaskedTextBox mtbBirthDay;
        private System.Windows.Forms.TextBox tbSex;
        private System.Windows.Forms.Label lbSex;
        private System.Windows.Forms.Label lbBirthDay;
        private System.Windows.Forms.Label lbPassword;
        private System.Windows.Forms.Label lbTelephone;
        private System.Windows.Forms.PictureBox pbRole;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.TextBox tbPPassword;
        private System.Windows.Forms.Label lbPPassword;
        private System.Windows.Forms.Panel plRole;
        private System.Windows.Forms.PictureBox pictureBox3;
        private AS2020DataSet aS2020DataSet;
        private System.Windows.Forms.BindingSource aS2020DataSetBindingSource;
        private System.Windows.Forms.BindingSource v_user_poreBindingSource;
        private AS2020DataSetTableAdapters.v_user_poreTableAdapter v_user_poreTableAdapter;
        private AS2020DataSetTableAdapters.TableAdapterManager tableAdapterManager;
    }
}