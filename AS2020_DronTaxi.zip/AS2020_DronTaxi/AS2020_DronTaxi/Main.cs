﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AS2020_DronTaxi
{
    public partial class Main : Form
    {
        private NpgsqlConnection conn;
        private string login;
        private string sql;
        private NpgsqlCommand cmd;
        private NpgsqlDataAdapter adapter;
        public Main(NpgsqlConnection conn, string login)
        {
            this.conn = conn;
            this.login = login;
            InitializeComponent();
            
        }

        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            
            try
            {
                selectUser();
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
            
        }

        private void Main_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            plMyProfile.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            plMyProfile.Visible = true;
        }

        private void btReg_Click(object sender, EventArgs e)
        {
            btReg.Visible = false;
            btCancel.Visible = true;
            btSave.Visible = true;
            lbPPassword.Visible = true;
            tbPPassword.Visible = true;

            tbFirstName.BackColor = Color.White;
            tbLastName.BackColor = Color.White;
            tbSecondName.BackColor = Color.White;
            tbPassword.BackColor = Color.White;
            tbPPassword.BackColor = Color.White;
            tbSex.BackColor = Color.White;
            tbEmail.BackColor = Color.White;
            mtbBirthDay.BackColor = Color.White;
            mtbTelephone.BackColor = Color.White;

            tbFirstName.Enabled = true;
            tbLastName.Enabled = true;
            tbSecondName.Enabled = true;
            tbPassword.Enabled = true;
            tbPPassword.Enabled = true;
            tbSex.Enabled = true;
            tbEmail.Enabled = true;
            mtbBirthDay.Enabled = true;
            mtbTelephone.Enabled = true;

            tbFirstName.ForeColor = Color.DarkMagenta;
            tbLastName.ForeColor = Color.DarkMagenta;
            tbSecondName.ForeColor = Color.DarkMagenta;
            tbPassword.ForeColor = Color.DarkMagenta;
            tbPPassword.ForeColor = Color.DarkMagenta;
            tbSex.ForeColor = Color.DarkMagenta;
            tbEmail.ForeColor = Color.DarkMagenta;
            mtbBirthDay.ForeColor = Color.DarkMagenta;
            mtbTelephone.ForeColor = Color.DarkMagenta;
        }

        private void btSave_Click(object sender, EventArgs e)
        {
            btSave.Visible = false;
            btCancel.Visible = false;
            btReg.Visible = true;
            lbPPassword.Visible = false;
            tbPPassword.Visible = false;

            tbFirstName.BackColor = Color.DarkMagenta;
            tbLastName.BackColor = Color.DarkMagenta;
            tbSecondName.BackColor = Color.DarkMagenta;
            tbPassword.BackColor = Color.DarkMagenta;
            tbPPassword.BackColor = Color.DarkMagenta;
            tbSex.BackColor = Color.DarkMagenta;
            tbEmail.BackColor = Color.DarkMagenta;
            mtbBirthDay.BackColor = Color.DarkMagenta;
            mtbTelephone.BackColor = Color.DarkMagenta;

            tbFirstName.Enabled = false;
            tbLastName.Enabled = false;
            tbSecondName.Enabled = false;
            tbPassword.Enabled = false;
            tbPPassword.Enabled = false;
            tbSex.Enabled = false;
            tbEmail.Enabled = false;
            mtbBirthDay.Enabled = false;
            mtbTelephone.Enabled = false;

            tbFirstName.ForeColor = Color.White;
            tbLastName.ForeColor = Color.White;
            tbSecondName.ForeColor = Color.White;
            tbPassword.ForeColor = Color.White;
            tbPPassword.ForeColor = Color.White;
            tbSex.ForeColor = Color.White;
            tbEmail.ForeColor = Color.White;
            mtbBirthDay.ForeColor = Color.White;
            mtbTelephone.ForeColor = Color.White;
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            btCancel.Visible = false;
            btSave.Visible = false;
            btReg.Visible = true;
            lbPPassword.Visible = false;
            tbPPassword.Visible = false;

            tbFirstName.BackColor = Color.DarkMagenta;
            tbLastName.BackColor = Color.DarkMagenta;
            tbSecondName.BackColor = Color.DarkMagenta;
            tbPassword.BackColor = Color.DarkMagenta;
            tbPPassword.BackColor = Color.DarkMagenta;
            tbSex.BackColor = Color.DarkMagenta;
            tbEmail.BackColor = Color.DarkMagenta;
            mtbBirthDay.BackColor = Color.DarkMagenta;
            mtbTelephone.BackColor = Color.DarkMagenta;

            tbFirstName.Enabled = false;
            tbLastName.Enabled = false;
            tbSecondName.Enabled = false;
            tbPassword.Enabled = false;
            tbPPassword.Enabled = false;
            tbSex.Enabled = false;
            tbEmail.Enabled = false;
            mtbBirthDay.Enabled = false;
            mtbTelephone.Enabled = false;

            tbFirstName.ForeColor = Color.White;
            tbLastName.ForeColor = Color.White;
            tbSecondName.ForeColor = Color.White;
            tbPassword.ForeColor = Color.White;
            tbPPassword.ForeColor = Color.White;
            tbSex.ForeColor = Color.White;
            tbEmail.ForeColor = Color.White;
            mtbBirthDay.ForeColor = Color.White;
            mtbTelephone.ForeColor = Color.White;
        }

        private void pbMyProfile_Click(object sender, EventArgs e)
        {
            plMyProfile.Visible = true;
            plRole.Visible = false;
            lbMyProfile.BackColor = Color.DarkMagenta;
            pbMyProfile.BackColor = Color.DarkMagenta;
            lbRole.BackColor = Color.DeepPink;
            pbRole.BackColor = Color.DeepPink;
        }


        private void pbRole_Click(object sender, EventArgs e)
        {
            plMyProfile.Visible = false;
            plRole.Visible = true;
            lbMyProfile.BackColor = Color.DeepPink;
            pbMyProfile.BackColor = Color.DeepPink;
            lbRole.BackColor = Color.DarkMagenta;
            pbRole.BackColor = Color.DarkMagenta;
        }

        private void selectUser()
        {
            try
            {
                conn.Open();
                sql = @"select * from get_user_login(:nlogin)";
                cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("nlogin", login);
                NpgsqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (reader.HasRows)
                    {
                        tbPassword.Text = reader[0].ToString();
                        tbFirstName.Text = reader[1].ToString();
                        tbSecondName.Text = reader[2].ToString();
                        tbLastName.Text = reader[3].ToString();
                        mtbBirthDay.Text = reader[4].ToString();
                        tbSex.Text = reader[5].ToString();
                        tbEmail.Text = reader[6].ToString();
                        mtbTelephone.Text = reader[7].ToString();
                    }
                    else
                    {
                        tbPassword.Text = "";
                        tbFirstName.Text = "";
                        tbSecondName.Text = "";
                        tbLastName.Text = "";
                        mtbBirthDay.Text = "";
                        tbSex.Text = "";
                        tbEmail.Text = "";
                        mtbTelephone.Text = "";
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Error: " + ex.Message);
            }

        }
    }
}
