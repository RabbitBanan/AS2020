﻿namespace AS2020_DronTaxi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btSave = new System.Windows.Forms.Button();
            this.btCancel = new System.Windows.Forms.Button();
            this.btReg = new System.Windows.Forms.Button();
            this.lbRole = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.mtbBirthDay = new System.Windows.Forms.MaskedTextBox();
            this.tbSex = new System.Windows.Forms.TextBox();
            this.lbSex = new System.Windows.Forms.Label();
            this.lbBirthDay = new System.Windows.Forms.Label();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.lbPassword = new System.Windows.Forms.Label();
            this.lbTelephone = new System.Windows.Forms.Label();
            this.lbEmail = new System.Windows.Forms.Label();
            this.tbLastName = new System.Windows.Forms.TextBox();
            this.tbFirstName = new System.Windows.Forms.TextBox();
            this.lbLastName = new System.Windows.Forms.Label();
            this.lbFirstName = new System.Windows.Forms.Label();
            this.tbSecondName = new System.Windows.Forms.TextBox();
            this.lbSecondName = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbMyProfile = new System.Windows.Forms.Label();
            this.pbRole = new System.Windows.Forms.PictureBox();
            this.pbMyProfile = new System.Windows.Forms.PictureBox();
            this.lbProfile = new System.Windows.Forms.Label();
            this.pbBack = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRole)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMyProfile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBack)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(402, 87);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(389, 319);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // btSave
            // 
            this.btSave.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btSave.BackColor = System.Drawing.Color.SpringGreen;
            this.btSave.Enabled = false;
            this.btSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btSave.Font = new System.Drawing.Font("Roboto Cn", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btSave.ForeColor = System.Drawing.SystemColors.Control;
            this.btSave.Location = new System.Drawing.Point(393, 363);
            this.btSave.Name = "btSave";
            this.btSave.Size = new System.Drawing.Size(147, 32);
            this.btSave.TabIndex = 57;
            this.btSave.Text = "Сохранить";
            this.btSave.UseVisualStyleBackColor = false;
            this.btSave.Visible = false;
            // 
            // btCancel
            // 
            this.btCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btCancel.BackColor = System.Drawing.Color.Turquoise;
            this.btCancel.Enabled = false;
            this.btCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btCancel.Font = new System.Drawing.Font("Roboto Cn", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btCancel.ForeColor = System.Drawing.SystemColors.Control;
            this.btCancel.Location = new System.Drawing.Point(572, 363);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(147, 32);
            this.btCancel.TabIndex = 56;
            this.btCancel.Text = "Отмена";
            this.btCancel.UseVisualStyleBackColor = false;
            this.btCancel.Visible = false;
            // 
            // btReg
            // 
            this.btReg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btReg.BackColor = System.Drawing.Color.Turquoise;
            this.btReg.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btReg.Font = new System.Drawing.Font("Roboto Cn", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btReg.ForeColor = System.Drawing.SystemColors.Control;
            this.btReg.Location = new System.Drawing.Point(572, 89);
            this.btReg.Name = "btReg";
            this.btReg.Size = new System.Drawing.Size(147, 32);
            this.btReg.TabIndex = 55;
            this.btReg.Text = "Редактировать";
            this.btReg.UseVisualStyleBackColor = false;
            // 
            // lbRole
            // 
            this.lbRole.AutoSize = true;
            this.lbRole.BackColor = System.Drawing.Color.DeepPink;
            this.lbRole.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbRole.Font = new System.Drawing.Font("Roboto", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbRole.ForeColor = System.Drawing.SystemColors.Control;
            this.lbRole.Location = new System.Drawing.Point(333, 43);
            this.lbRole.Name = "lbRole";
            this.lbRole.Size = new System.Drawing.Size(69, 29);
            this.lbRole.TabIndex = 54;
            this.lbRole.Text = "Роли";
            this.lbRole.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.BackColor = System.Drawing.Color.MediumVioletRed;
            this.maskedTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.maskedTextBox1.Font = new System.Drawing.Font("Roboto Cn", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.maskedTextBox1.ForeColor = System.Drawing.SystemColors.Window;
            this.maskedTextBox1.Location = new System.Drawing.Point(517, 223);
            this.maskedTextBox1.Mask = "(999) 000-0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(234, 20);
            this.maskedTextBox1.TabIndex = 53;
            this.maskedTextBox1.Text = "1234567890";
            // 
            // mtbBirthDay
            // 
            this.mtbBirthDay.BackColor = System.Drawing.Color.MediumVioletRed;
            this.mtbBirthDay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mtbBirthDay.Font = new System.Drawing.Font("Roboto Cn", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mtbBirthDay.ForeColor = System.Drawing.SystemColors.Window;
            this.mtbBirthDay.Location = new System.Drawing.Point(165, 333);
            this.mtbBirthDay.Mask = "00/00/0000";
            this.mtbBirthDay.Name = "mtbBirthDay";
            this.mtbBirthDay.Size = new System.Drawing.Size(123, 20);
            this.mtbBirthDay.TabIndex = 52;
            this.mtbBirthDay.Text = "00000000";
            this.mtbBirthDay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mtbBirthDay.ValidatingType = typeof(System.DateTime);
            // 
            // tbSex
            // 
            this.tbSex.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.tbSex.BackColor = System.Drawing.Color.MediumVioletRed;
            this.tbSex.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSex.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbSex.ForeColor = System.Drawing.SystemColors.Window;
            this.tbSex.Location = new System.Drawing.Point(319, 332);
            this.tbSex.Name = "tbSex";
            this.tbSex.Size = new System.Drawing.Size(119, 20);
            this.tbSex.TabIndex = 50;
            this.tbSex.Text = "Пол";
            this.tbSex.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbSex
            // 
            this.lbSex.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbSex.AutoSize = true;
            this.lbSex.BackColor = System.Drawing.Color.Transparent;
            this.lbSex.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbSex.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbSex.ForeColor = System.Drawing.SystemColors.Control;
            this.lbSex.Location = new System.Drawing.Point(315, 310);
            this.lbSex.Name = "lbSex";
            this.lbSex.Size = new System.Drawing.Size(38, 19);
            this.lbSex.TabIndex = 51;
            this.lbSex.Text = "Пол";
            this.lbSex.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbBirthDay
            // 
            this.lbBirthDay.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbBirthDay.AutoSize = true;
            this.lbBirthDay.BackColor = System.Drawing.Color.Transparent;
            this.lbBirthDay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbBirthDay.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbBirthDay.ForeColor = System.Drawing.SystemColors.Control;
            this.lbBirthDay.Location = new System.Drawing.Point(161, 310);
            this.lbBirthDay.Name = "lbBirthDay";
            this.lbBirthDay.Size = new System.Drawing.Size(127, 19);
            this.lbBirthDay.TabIndex = 49;
            this.lbBirthDay.Text = "День рождения";
            this.lbBirthDay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbPassword
            // 
            this.tbPassword.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.tbPassword.BackColor = System.Drawing.Color.MediumVioletRed;
            this.tbPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbPassword.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbPassword.ForeColor = System.Drawing.SystemColors.Window;
            this.tbPassword.Location = new System.Drawing.Point(517, 274);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.PasswordChar = '*';
            this.tbPassword.Size = new System.Drawing.Size(234, 20);
            this.tbPassword.TabIndex = 48;
            this.tbPassword.Text = "Пароль";
            // 
            // lbPassword
            // 
            this.lbPassword.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbPassword.AutoSize = true;
            this.lbPassword.BackColor = System.Drawing.Color.Transparent;
            this.lbPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbPassword.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbPassword.ForeColor = System.Drawing.SystemColors.Control;
            this.lbPassword.Location = new System.Drawing.Point(491, 252);
            this.lbPassword.Name = "lbPassword";
            this.lbPassword.Size = new System.Drawing.Size(65, 19);
            this.lbPassword.TabIndex = 47;
            this.lbPassword.Text = "Пароль";
            this.lbPassword.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTelephone
            // 
            this.lbTelephone.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbTelephone.AutoSize = true;
            this.lbTelephone.BackColor = System.Drawing.Color.Transparent;
            this.lbTelephone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbTelephone.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbTelephone.ForeColor = System.Drawing.SystemColors.Control;
            this.lbTelephone.Location = new System.Drawing.Point(491, 201);
            this.lbTelephone.Name = "lbTelephone";
            this.lbTelephone.Size = new System.Drawing.Size(75, 19);
            this.lbTelephone.TabIndex = 46;
            this.lbTelephone.Text = "Телефон";
            this.lbTelephone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbEmail
            // 
            this.lbEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbEmail.AutoSize = true;
            this.lbEmail.BackColor = System.Drawing.Color.Transparent;
            this.lbEmail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbEmail.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbEmail.ForeColor = System.Drawing.SystemColors.Control;
            this.lbEmail.Location = new System.Drawing.Point(491, 150);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(49, 19);
            this.lbEmail.TabIndex = 45;
            this.lbEmail.Text = "Email";
            this.lbEmail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbLastName
            // 
            this.tbLastName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.tbLastName.BackColor = System.Drawing.Color.MediumVioletRed;
            this.tbLastName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbLastName.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbLastName.ForeColor = System.Drawing.SystemColors.Window;
            this.tbLastName.Location = new System.Drawing.Point(196, 274);
            this.tbLastName.Name = "tbLastName";
            this.tbLastName.Size = new System.Drawing.Size(234, 20);
            this.tbLastName.TabIndex = 36;
            this.tbLastName.Text = "Отчество";
            // 
            // tbFirstName
            // 
            this.tbFirstName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.tbFirstName.BackColor = System.Drawing.Color.MediumVioletRed;
            this.tbFirstName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbFirstName.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbFirstName.ForeColor = System.Drawing.SystemColors.Window;
            this.tbFirstName.Location = new System.Drawing.Point(196, 223);
            this.tbFirstName.Name = "tbFirstName";
            this.tbFirstName.Size = new System.Drawing.Size(234, 20);
            this.tbFirstName.TabIndex = 35;
            this.tbFirstName.Text = "Имя";
            // 
            // lbLastName
            // 
            this.lbLastName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbLastName.AutoSize = true;
            this.lbLastName.BackColor = System.Drawing.Color.Transparent;
            this.lbLastName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbLastName.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbLastName.ForeColor = System.Drawing.SystemColors.Control;
            this.lbLastName.Location = new System.Drawing.Point(170, 252);
            this.lbLastName.Name = "lbLastName";
            this.lbLastName.Size = new System.Drawing.Size(79, 19);
            this.lbLastName.TabIndex = 44;
            this.lbLastName.Text = "Отчестов";
            this.lbLastName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbFirstName
            // 
            this.lbFirstName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbFirstName.AutoSize = true;
            this.lbFirstName.BackColor = System.Drawing.Color.Transparent;
            this.lbFirstName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbFirstName.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbFirstName.ForeColor = System.Drawing.SystemColors.Control;
            this.lbFirstName.Location = new System.Drawing.Point(170, 201);
            this.lbFirstName.Name = "lbFirstName";
            this.lbFirstName.Size = new System.Drawing.Size(41, 19);
            this.lbFirstName.TabIndex = 43;
            this.lbFirstName.Text = "Имя";
            this.lbFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbSecondName
            // 
            this.tbSecondName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.tbSecondName.BackColor = System.Drawing.Color.MediumVioletRed;
            this.tbSecondName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSecondName.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbSecondName.ForeColor = System.Drawing.SystemColors.Window;
            this.tbSecondName.Location = new System.Drawing.Point(196, 172);
            this.tbSecondName.Name = "tbSecondName";
            this.tbSecondName.Size = new System.Drawing.Size(234, 20);
            this.tbSecondName.TabIndex = 34;
            this.tbSecondName.Text = "Фамилия";
            // 
            // lbSecondName
            // 
            this.lbSecondName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbSecondName.AutoSize = true;
            this.lbSecondName.BackColor = System.Drawing.Color.Transparent;
            this.lbSecondName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbSecondName.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbSecondName.ForeColor = System.Drawing.SystemColors.Control;
            this.lbSecondName.Location = new System.Drawing.Point(170, 150);
            this.lbSecondName.Name = "lbSecondName";
            this.lbSecondName.Size = new System.Drawing.Size(78, 19);
            this.lbSecondName.TabIndex = 42;
            this.lbSecondName.Text = "Фамилия";
            this.lbSecondName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::AS2020_DronTaxi.Properties.Resources.clear_prof_circle;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.InitialImage = global::AS2020_DronTaxi.Properties.Resources.clear_prof;
            this.pictureBox1.Location = new System.Drawing.Point(27, 150);
            this.pictureBox1.MaximumSize = new System.Drawing.Size(103, 92);
            this.pictureBox1.MinimumSize = new System.Drawing.Size(103, 92);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 92);
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // lbMyProfile
            // 
            this.lbMyProfile.AutoSize = true;
            this.lbMyProfile.BackColor = System.Drawing.Color.Transparent;
            this.lbMyProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbMyProfile.Font = new System.Drawing.Font("Roboto", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbMyProfile.ForeColor = System.Drawing.SystemColors.Control;
            this.lbMyProfile.Location = new System.Drawing.Point(41, 43);
            this.lbMyProfile.Name = "lbMyProfile";
            this.lbMyProfile.Size = new System.Drawing.Size(171, 29);
            this.lbMyProfile.TabIndex = 40;
            this.lbMyProfile.Text = "Мой профиль";
            this.lbMyProfile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbRole
            // 
            this.pbRole.BackColor = System.Drawing.Color.DeepPink;
            this.pbRole.Location = new System.Drawing.Point(245, 37);
            this.pbRole.Name = "pbRole";
            this.pbRole.Size = new System.Drawing.Size(244, 40);
            this.pbRole.TabIndex = 39;
            this.pbRole.TabStop = false;
            // 
            // pbMyProfile
            // 
            this.pbMyProfile.Location = new System.Drawing.Point(4, 37);
            this.pbMyProfile.Name = "pbMyProfile";
            this.pbMyProfile.Size = new System.Drawing.Size(244, 40);
            this.pbMyProfile.TabIndex = 38;
            this.pbMyProfile.TabStop = false;
            // 
            // lbProfile
            // 
            this.lbProfile.AutoSize = true;
            this.lbProfile.BackColor = System.Drawing.Color.Purple;
            this.lbProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbProfile.Font = new System.Drawing.Font("Roboto", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbProfile.ForeColor = System.Drawing.SystemColors.Control;
            this.lbProfile.Location = new System.Drawing.Point(-1, -5);
            this.lbProfile.Name = "lbProfile";
            this.lbProfile.Size = new System.Drawing.Size(171, 29);
            this.lbProfile.TabIndex = 37;
            this.lbProfile.Text = "Мой профиль";
            this.lbProfile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbBack
            // 
            this.pbBack.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbBack.BackColor = System.Drawing.Color.Purple;
            this.pbBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pbBack.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbBack.Location = new System.Drawing.Point(-42, -27);
            this.pbBack.Name = "pbBack";
            this.pbBack.Size = new System.Drawing.Size(884, 504);
            this.pbBack.TabIndex = 33;
            this.pbBack.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btSave);
            this.Controls.Add(this.btCancel);
            this.Controls.Add(this.btReg);
            this.Controls.Add(this.lbRole);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.mtbBirthDay);
            this.Controls.Add(this.tbSex);
            this.Controls.Add(this.lbSex);
            this.Controls.Add(this.lbBirthDay);
            this.Controls.Add(this.tbPassword);
            this.Controls.Add(this.lbPassword);
            this.Controls.Add(this.lbTelephone);
            this.Controls.Add(this.lbEmail);
            this.Controls.Add(this.tbLastName);
            this.Controls.Add(this.tbFirstName);
            this.Controls.Add(this.lbLastName);
            this.Controls.Add(this.lbFirstName);
            this.Controls.Add(this.tbSecondName);
            this.Controls.Add(this.lbSecondName);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbMyProfile);
            this.Controls.Add(this.pbRole);
            this.Controls.Add(this.pbMyProfile);
            this.Controls.Add(this.lbProfile);
            this.Controls.Add(this.pbBack);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRole)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMyProfile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBack)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btSave;
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.Button btReg;
        private System.Windows.Forms.Label lbRole;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.MaskedTextBox mtbBirthDay;
        private System.Windows.Forms.TextBox tbSex;
        private System.Windows.Forms.Label lbSex;
        private System.Windows.Forms.Label lbBirthDay;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.Label lbPassword;
        private System.Windows.Forms.Label lbTelephone;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.TextBox tbLastName;
        private System.Windows.Forms.TextBox tbFirstName;
        private System.Windows.Forms.Label lbLastName;
        private System.Windows.Forms.Label lbFirstName;
        private System.Windows.Forms.TextBox tbSecondName;
        private System.Windows.Forms.Label lbSecondName;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbMyProfile;
        private System.Windows.Forms.PictureBox pbRole;
        private System.Windows.Forms.PictureBox pbMyProfile;
        private System.Windows.Forms.Label lbProfile;
        private System.Windows.Forms.PictureBox pbBack;
    }
}