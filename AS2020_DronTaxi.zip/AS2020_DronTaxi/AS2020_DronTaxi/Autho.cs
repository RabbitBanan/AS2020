﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AS2020_DronTaxi
{
    public partial class frAuthorization : Form
    {
        private Boolean saveLoginPassoword;
        private string connstring;
        private NpgsqlConnection conn;
        public frAuthorization()
        {
            
            InitializeComponent();
        }
        
        

        private void imgCheckBox_Click(object sender, EventArgs e)
        {
            if (saveLoginPassoword) { 
                saveLoginPassoword = false;
                imgCheckBox.Image = AS2020_DronTaxi.Properties.Resources.input_checkbox_check;
            } else {
                saveLoginPassoword = true;
                imgCheckBox.Image = AS2020_DronTaxi.Properties.Resources.input_checkbox;
            }
                
        }

        private void frAuthorization_Load(object sender, EventArgs e)
        {
            saveLoginPassoword = false;
        }

        private void lbSaveLogPas_Click(object sender, EventArgs e)
        {
            if (saveLoginPassoword)
            {
                saveLoginPassoword = false;
                imgCheckBox.Image = AS2020_DronTaxi.Properties.Resources.input_checkbox_check;
            }
            else
            {
                saveLoginPassoword = true;
                imgCheckBox.Image = AS2020_DronTaxi.Properties.Resources.input_checkbox;
            }
        }

        private void btToCome_Click(object sender, EventArgs e)
        {
            if (tbLogin.Text.Length != 0 && tbPassword.Text.Length != 0)
            {
                try
                {
                    connstring = String.Format("Server={0};Port={1};User ID={2};Password={3};Database={4}",
                                               "localhost", 5432, tbLogin.Text, tbPassword.Text, "AS2020");
                    conn = new NpgsqlConnection(connstring);
                    conn.Open();
                    conn.Close();

                    Form main = new Main(conn, tbLogin.Text);
                    main.Show();
                    this.Hide();
                }
                catch (Exception ex)
                {
                    conn.Close();
                    MessageBox.Show("Error: " + ex.Message);
                }
                

            }
        }

        private void frAuthorization_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) this.Close();
        }
    }
}
