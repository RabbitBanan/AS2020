﻿namespace AS2020_DronTaxi
{
    partial class frAuthorization
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frAuthorization));
            this.lbNameApp = new System.Windows.Forms.Label();
            this.pbLogoApp = new System.Windows.Forms.PictureBox();
            this.lbAuthorization = new System.Windows.Forms.Label();
            this.lbLogin = new System.Windows.Forms.Label();
            this.lbPassword = new System.Windows.Forms.Label();
            this.tbLogin = new System.Windows.Forms.TextBox();
            this.imgCheckBox = new System.Windows.Forms.PictureBox();
            this.btToCome = new System.Windows.Forms.Button();
            this.lbSaveLogPas = new System.Windows.Forms.Label();
            this.btReg = new System.Windows.Forms.Button();
            this.tbPassword = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogoApp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgCheckBox)).BeginInit();
            this.SuspendLayout();
            // 
            // lbNameApp
            // 
            this.lbNameApp.AutoSize = true;
            this.lbNameApp.BackColor = System.Drawing.Color.Transparent;
            this.lbNameApp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbNameApp.Font = new System.Drawing.Font("Roboto Cn", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbNameApp.ForeColor = System.Drawing.SystemColors.Control;
            this.lbNameApp.Location = new System.Drawing.Point(114, 22);
            this.lbNameApp.Name = "lbNameApp";
            this.lbNameApp.Size = new System.Drawing.Size(238, 58);
            this.lbNameApp.TabIndex = 0;
            this.lbNameApp.Text = "DRON TAXI";
            this.lbNameApp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbLogoApp
            // 
            this.pbLogoApp.BackColor = System.Drawing.Color.Transparent;
            this.pbLogoApp.Image = ((System.Drawing.Image)(resources.GetObject("pbLogoApp.Image")));
            this.pbLogoApp.InitialImage = null;
            this.pbLogoApp.Location = new System.Drawing.Point(12, 12);
            this.pbLogoApp.Name = "pbLogoApp";
            this.pbLogoApp.Size = new System.Drawing.Size(96, 78);
            this.pbLogoApp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogoApp.TabIndex = 1;
            this.pbLogoApp.TabStop = false;
            // 
            // lbAuthorization
            // 
            this.lbAuthorization.AutoSize = true;
            this.lbAuthorization.BackColor = System.Drawing.Color.Transparent;
            this.lbAuthorization.Font = new System.Drawing.Font("Roboto Cn", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbAuthorization.ForeColor = System.Drawing.SystemColors.Control;
            this.lbAuthorization.Location = new System.Drawing.Point(25, 134);
            this.lbAuthorization.Name = "lbAuthorization";
            this.lbAuthorization.Size = new System.Drawing.Size(163, 29);
            this.lbAuthorization.TabIndex = 2;
            this.lbAuthorization.Text = "АВТОРИЗАЦИЯ";
            // 
            // lbLogin
            // 
            this.lbLogin.AutoSize = true;
            this.lbLogin.BackColor = System.Drawing.Color.Transparent;
            this.lbLogin.Font = new System.Drawing.Font("Roboto Cn", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbLogin.ForeColor = System.Drawing.SystemColors.Control;
            this.lbLogin.Location = new System.Drawing.Point(26, 163);
            this.lbLogin.Name = "lbLogin";
            this.lbLogin.Size = new System.Drawing.Size(56, 23);
            this.lbLogin.TabIndex = 3;
            this.lbLogin.Text = "Логин";
            // 
            // lbPassword
            // 
            this.lbPassword.AutoSize = true;
            this.lbPassword.BackColor = System.Drawing.Color.Transparent;
            this.lbPassword.Font = new System.Drawing.Font("Roboto Cn", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbPassword.ForeColor = System.Drawing.SystemColors.Control;
            this.lbPassword.Location = new System.Drawing.Point(26, 225);
            this.lbPassword.Name = "lbPassword";
            this.lbPassword.Size = new System.Drawing.Size(67, 23);
            this.lbPassword.TabIndex = 4;
            this.lbPassword.Text = "Пароль";
            // 
            // tbLogin
            // 
            this.tbLogin.Font = new System.Drawing.Font("Roboto Cn", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbLogin.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.tbLogin.Location = new System.Drawing.Point(30, 189);
            this.tbLogin.Name = "tbLogin";
            this.tbLogin.Size = new System.Drawing.Size(274, 33);
            this.tbLogin.TabIndex = 1;
            // 
            // imgCheckBox
            // 
            this.imgCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.imgCheckBox.Image = global::AS2020_DronTaxi.Properties.Resources.input_checkbox;
            this.imgCheckBox.InitialImage = null;
            this.imgCheckBox.Location = new System.Drawing.Point(30, 299);
            this.imgCheckBox.Name = "imgCheckBox";
            this.imgCheckBox.Size = new System.Drawing.Size(20, 20);
            this.imgCheckBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgCheckBox.TabIndex = 7;
            this.imgCheckBox.TabStop = false;
            this.imgCheckBox.Click += new System.EventHandler(this.imgCheckBox_Click);
            // 
            // btToCome
            // 
            this.btToCome.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btToCome.Font = new System.Drawing.Font("Roboto Cn", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btToCome.ForeColor = System.Drawing.SystemColors.Control;
            this.btToCome.Location = new System.Drawing.Point(176, 290);
            this.btToCome.Name = "btToCome";
            this.btToCome.Size = new System.Drawing.Size(128, 39);
            this.btToCome.TabIndex = 3;
            this.btToCome.Text = "Войти";
            this.btToCome.UseVisualStyleBackColor = false;
            this.btToCome.Click += new System.EventHandler(this.btToCome_Click);
            // 
            // lbSaveLogPas
            // 
            this.lbSaveLogPas.AutoSize = true;
            this.lbSaveLogPas.BackColor = System.Drawing.Color.Transparent;
            this.lbSaveLogPas.Font = new System.Drawing.Font("Roboto", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbSaveLogPas.ForeColor = System.Drawing.SystemColors.Control;
            this.lbSaveLogPas.Location = new System.Drawing.Point(56, 300);
            this.lbSaveLogPas.Name = "lbSaveLogPas";
            this.lbSaveLogPas.Size = new System.Drawing.Size(85, 18);
            this.lbSaveLogPas.TabIndex = 9;
            this.lbSaveLogPas.Text = "Запомнить";
            this.lbSaveLogPas.Click += new System.EventHandler(this.lbSaveLogPas_Click);
            // 
            // btReg
            // 
            this.btReg.BackColor = System.Drawing.Color.LightGreen;
            this.btReg.Enabled = false;
            this.btReg.Font = new System.Drawing.Font("Roboto Cn", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btReg.ForeColor = System.Drawing.SystemColors.GrayText;
            this.btReg.Location = new System.Drawing.Point(30, 334);
            this.btReg.Name = "btReg";
            this.btReg.Size = new System.Drawing.Size(274, 39);
            this.btReg.TabIndex = 4;
            this.btReg.Text = "Регистрация";
            this.btReg.UseVisualStyleBackColor = false;
            // 
            // tbPassword
            // 
            this.tbPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbPassword.Font = new System.Drawing.Font("Roboto Cn", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbPassword.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.tbPassword.Location = new System.Drawing.Point(30, 251);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.PasswordChar = '*';
            this.tbPassword.Size = new System.Drawing.Size(274, 33);
            this.tbPassword.TabIndex = 2;
            // 
            // frAuthorization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = global::AS2020_DronTaxi.Properties.Resources.flying_taxi;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbPassword);
            this.Controls.Add(this.btReg);
            this.Controls.Add(this.lbSaveLogPas);
            this.Controls.Add(this.btToCome);
            this.Controls.Add(this.imgCheckBox);
            this.Controls.Add(this.tbLogin);
            this.Controls.Add(this.lbPassword);
            this.Controls.Add(this.lbLogin);
            this.Controls.Add(this.lbAuthorization);
            this.Controls.Add(this.pbLogoApp);
            this.Controls.Add(this.lbNameApp);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(816, 489);
            this.Name = "frAuthorization";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dron Taxi";
            this.Load += new System.EventHandler(this.frAuthorization_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frAuthorization_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pbLogoApp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgCheckBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbNameApp;
        private System.Windows.Forms.PictureBox pbLogoApp;
        private System.Windows.Forms.Label lbAuthorization;
        private System.Windows.Forms.Label lbLogin;
        private System.Windows.Forms.Label lbPassword;
        private System.Windows.Forms.TextBox tbLogin;
        private System.Windows.Forms.PictureBox imgCheckBox;
        private System.Windows.Forms.Button btToCome;
        private System.Windows.Forms.Label lbSaveLogPas;
        private System.Windows.Forms.Button btReg;
        private System.Windows.Forms.TextBox tbPassword;
    }
}

